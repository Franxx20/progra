#ifndef CADENA_H_INCLUDED
#define CADENA_H_INCLUDED

#include <stdbool.h>

int miStrlen(const char *cad);
bool esPalindromo(const char *cad);
bool sonAnagramas(const char *cad1, const char *cad2);

#endif // CADENA_H_INCLUDED
