#ifndef CADENA_H_INCLUDED
#define CADENA_H_INCLUDED

void normalizar(const char *texto, char *textoNormalizado);

#endif // CADENA_H_INCLUDED
