#ifndef hcom
#define hcom

#define COMVALUE 100
#define NEWVALUE 101
int funcion();

#endif
