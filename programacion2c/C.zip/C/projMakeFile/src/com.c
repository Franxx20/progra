#include "com.h"
#include "init.h"
#include <stdio.h>

int funcion() {
  printf("hola mi nombre es Franco Javier");
  return 1;
}
