#ifndef TDALISTAIMPLDINAMICA_H
#define TDALISTAIMPLDINAMICA_H

#include "../Nodo/Nodo.h"

typedef Nodo* Lista;


#endif // TDALISTAIMPLDINAMICA_H
