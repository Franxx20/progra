#ifndef COMPLEJO_H
#define COMPLEJO_H


class Complejo
{
	private:

	public:
};


#endif // COMPLEJO_H
