#ifndef PILAESTATICA_H_INCLUDED
#define PILAESTATICA_H_INCLUDED

#define TAM_PILA 400

typedef struct {
  char vec[TAM_PILA];
  unsigned tope;
} Pila;

#endif // PILAESTATICA_H_INCLUDED
