#include <locale.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "../Solucion2doParcialArmadoPC/Solucion2doParcialArmadoPC.h"



#include "../TDAArbolImplDinamica/TDAArbolImplDinamica.h"
#include "../TDAArbol/TDAArbol.h"
#include "../TDAListaImplDinamicaDoble/TDAListaImplDinamicaDoble.h"
#include "../TDALista/TDALista.h"
#include "../TDA/TDA.h"
#include "../Solucion2doParcialArmadoPC/TiposArmadoPC.h"

int actualizarComponentes_alu(const char* pathComponentes, const char* pathArmadoYRep);



int obtenerReg(ArmadoYRep* ayr, Arbol* idxComp);
void eliminarDuplicadosDeLista(Lista* aYrLista, Cmp cmp, Actualizar actualizar);

int cmpCod(const void* pv1, const void* pv2);
void actualizarAYR(void* pvpActualizado, const void* pvpActualizador);
int cmpAYR(const void* pv1, const void* pv2);

int eliminarDeListaPrimero2(Lista* armYrep,void* aYr, size_t ArmadoYRep);
int buscarEnListaDesord2(const Lista* armYrep,void* compont, size_t Componente,Cmp cmpCod);

#define ARG_PATH_COMP 1
#define ARG_PATH_ARM_REP 2


int main(int argc, char* argv[])
{
    setlocale(LC_ALL, "spanish");	// Cambiar locale - Suficiente para m�quinas Linux
    SetConsoleCP(1252); 			// Cambiar STDIN -  Para m�quinas Windows
    SetConsoleOutputCP(1252);		// Cambiar STDOUT - Para m�quinas Windows

    generarArchivoStockComponentes(argv[ARG_PATH_COMP]);

    generarArchivoArmadosYReparaciones(argv[ARG_PATH_ARM_REP]);

	puts("Componentes antes de actualizar:\n");
	mostrarArchivoComponentes(argv[ARG_PATH_COMP]);
	puts("");

	puts("Armados/Reparaciones:");
	mostrarArchivoArmadoYRep(argv[ARG_PATH_ARM_REP]);
	puts("");
    int resp = actualizarComponentes(argv[ARG_PATH_COMP], argv[ARG_PATH_ARM_REP]);
	///************************************************************************************
	///******** Descomente esta l�nea y comente la de arriba para probar su c�digo ********
	 //int resp = actualizarComponentes_alu(argv[ARG_PATH_COMP], argv[ARG_PATH_ARM_REP]);
	///************************************************************************************

	if(resp != TODO_OK)
	{
		puts("Error actualizando los componentes.");
		return resp;
	}


	puts("\nComponentes despues de actualizar:\n");
	mostrarArchivoComponentes(argv[ARG_PATH_COMP]);

    return 0;
}


int actualizarComponentes_alu(const char* pathComponentes, const char* pathArmadoYRep)
{
///	Resolver.
/// Nota: Resuelva esta, y todas las funciones que necesite, en este archivo. Que ser� el que debe entregar. No modifique ni entregue otro/s archivos del proyecto.
/// Agregue el sufijo "_alu" a todas las funciones que genere.FILE* bin;
    //char* pathCompIdx;
    //obtenerPathIdx(pathComponentes, pathCompIdx);

    Lista armYrep;
    crearLista(&armYrep);


    Arbol idxComp;
    crearArbol(&idxComp);
    cargarArbol(&idxComp, sizeof(IndComponente), "Componentes.idx");


    Componente compont;
    ArmadoYRep aYr;

    FILE* binCOMP;
    binCOMP = fopen(pathComponentes, "r+b");

    int reg;


    cargarArmadosYRepEnLista(pathArmadoYRep, &armYrep);
    eliminarDuplicadosDeLista(&armYrep, cmpAYR, actualizarAYR);

    cargarArbol(&idxComp, sizeof(IndComponente), "Componentes.idx");
    int i =1 ;
    while(eliminarDeListaPrimero2(&armYrep, &aYr, sizeof(ArmadoYRep)))
    {

        reg = obtenerReg(&aYr, &idxComp);

        fseek(binCOMP, (long)+sizeof(Componente)*reg, SEEK_SET);

        fread(&compont, sizeof(Componente), 1, binCOMP);
        compont.stock -= aYr.cantidad;

        fseek(binCOMP, (long)-sizeof(Componente), SEEK_CUR);
        fwrite(&compont, sizeof(Componente), 1, binCOMP);
        fseek(binCOMP, 0, SEEK_CUR);
        fseek(binCOMP, (long)+sizeof(Componente)*i, SEEK_SET);
        i++;

    }
    fclose(binCOMP);

    return TODO_OK;
}
int eliminarDeListaPrimero2(Lista* pl, void* dato, size_t tamElem)
{
    NodoD* nae = *pl;

    if(!nae)
        return 0; /// FALSO

    while(nae->ant)//voy al inicio de lista
        nae = nae->ant;

    if(nae->sig)// si no es el primero
        nae->sig->ant = NULL;

    if(nae == *pl)// si es el primero
        *pl = nae->sig;

    memcpy(dato, nae->dato, min(tamElem, nae->tamElem));

    free(nae->dato);
    free(nae);

    return 1; /// VERDADERO
}

void eliminarDuplicadosDeLista(Lista* aYrLista, Cmp cmpAYR, Actualizar actualizarAYR)
{
    NodoD* n1 = *aYrLista;

    if(!n1)
        return ;

    while(n1->ant)
        n1 = n1->ant;

    NodoD* n2;
    NodoD* nae;
    NodoD* aux = n1;


    while(n1)
    {
        n2 = n1;
        aux = aux->sig;

        while(aux)
        {


            if(cmpAYR(aux->dato, n2->dato) == 0)
            {
                nae = aux;
                if(nae->ant)
                    nae->ant->sig = nae->sig;
                if(nae->sig)
                    nae->sig->ant = nae->ant;
                actualizarAYR(n2->dato, aux->dato);

                aux = nae->ant;
                free(nae->dato);
                free(nae);
            }

            aux = aux->sig;

        }

        n1 = n1->sig;
        aux = n1;
    }
    *aYrLista = n2;
}

int obtenerReg(ArmadoYRep* ayr, Arbol* idxComp)
{
    IndComponente path;

    strcpy(path.codigo, ayr->codigo);

    buscarEnArbol(idxComp, &path, sizeof(ArmadoYRep), cmpCod);


    return path.nroReg;
}

int cmpCod(const void* pv1, const void* pv2)
{
    IndComponente* comp1 = (IndComponente*)pv1;
    IndComponente* comp2 = (IndComponente*)pv2;

    return strcmp(comp1->codigo, comp2->codigo);
}


int cmpAYR(const void* pv1, const void* pv2)
{
    ArmadoYRep* comp1 = (ArmadoYRep*)pv1;
    ArmadoYRep* comp2 = (ArmadoYRep*)pv2;

    return strcmp(comp1->codigo, comp2->codigo);
}

void actualizarAYR(void* pvpActualizado, const void* pvpActualizador)
{
    ArmadoYRep* prodActualizado = (ArmadoYRep*)pvpActualizado;
    ArmadoYRep* prodActualizador = (ArmadoYRep*)pvpActualizador;

    prodActualizado->cantidad += prodActualizador->cantidad;
}


int buscarEnListaDesord2(const Lista* pl, void* dato, size_t tamElem, Cmp cmp)
{
    NodoD* act = *pl;
    NodoD* aux = *pl;

    while(act->ant && cmp(dato, act->dato) != 0 )
            act = act->ant;

    while(aux->sig && cmp(dato, aux->dato) != 0 )
            act = act->sig;

    int comp = cmp(dato, act->dato);

    if(comp == 0)
    {
        memcpy(dato, act->dato, min(tamElem, act->tamElem));
        return 1;
    }
    else
        return 0;
}

