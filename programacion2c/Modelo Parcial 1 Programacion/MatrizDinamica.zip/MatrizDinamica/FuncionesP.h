#ifndef FUNCIONESP_H_INCLUDED
#define FUNCIONESP_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

#define FIL 4
#define COL 4

int cargarMemoria (int ***mat, int fil, int col);
void  liberoMemoria (int **mat, int fil);
void cargarMatriz(int **mat, int fil, int col);
void mostrarMatriz(int **mat, int fil, int col);


#endif // FUNCIONESP_H_INCLUDED
