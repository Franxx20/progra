#include "FuncionesP.h"

int main()
{
    int **mat;

    if(cargarMemoria(&mat,FIL,COL))
    {
        cargarMatriz(mat,FIL,COL);

        printf("Matriz\n");
        mostrarMatriz(mat,FIL,COL);

        liberoMemoria(mat,FIL);

    }
    return 0;
}
