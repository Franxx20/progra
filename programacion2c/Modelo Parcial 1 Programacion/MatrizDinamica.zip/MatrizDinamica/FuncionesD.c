#include "FuncionesP.h"


int cargarMemoria (int ***mat, int fil, int col)
{
    int i;

    *mat=malloc(fil*sizeof(int*));
    if(!mat)
    {
        return 0;
    }

    for(i=0; i<fil; i++)
    {
        (*mat)[i]= malloc(col*sizeof(int));
        if(!mat)
        {
            liberoMemoria(*mat, i);
            return 0;
        }
    }
    return 1;
}

void  liberoMemoria (int **mat, int fil)
{
    int i;

    for(i=0; i<fil; i++)
    {
        free(mat[i]);
    }
    free(mat);
}

void cargarMatriz(int **mat, int fil, int col)
{
    int i,
        j;

        for(i=0; i<fil; i++)
        {
            for(j=0; j<col; j++)
            {
                mat[i][j]=i+j;
            }
        }
}

void mostrarMatriz(int **mat, int fil, int col)
{
    int i,
        j;

    for(i=0; i<fil; i++)
    {
        for(j=0; j<col; j++)
        {
            printf("%d\t", mat[i][j]);
        }
        puts(" ");
    }
}
