#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/// Descomentar lo que corresponda. Si Recupera parcial 1: TDA_LISTA_IMPL_DINAMICA. Si es parcial 2: TDA_LISTA_IMPL_DINAMICA_DOBLE.
//#define TDA_LISTA_IMPL_DINAMICA
#define TDA_LISTA_IMPL_DINAMICA_DOBLE
#include "../TDALista/TDAlista.h"

#include "../SolucionAlumnos/SolucionAlumnos.h"

#include "../Matematica/Matematica.h"

#define NOMBRE_ARCHIVO_NOTAS "Notas.dat"

void procesarLista_ALU(Lista* plAM);
int sacarDeLista(Lista* plista);
EstadoAlumnoMateria buscarAlumno(Lista* plista,EstadoAlumnoMateria alumnoAEncontrar, size_t tamElem);
int verTope(Lista* plista,void* elem, size_t tamElem);

int main()
{
    generarArchivo(NOMBRE_ARCHIVO_NOTAS);

    Lista listaAM;
    crearLista(&listaAM);

    cargarLista(&listaAM, NOMBRE_ARCHIVO_NOTAS);

    puts("Lista antes de procesar:");
    recorrerLista(&listaAM, mostrarEstadoAM, NULL);

    procesarLista_ALU(&listaAM);
    //procesarLista(&listaAM);

    puts("\nLista despues de procesar:");
    recorrerLista(&listaAM, mostrarEstadoAM, NULL);

    return 0;
}


void procesarLista_ALU(Lista* plAM)
{
    /// Desarrolle esta función y todas las que invoque. Puede usar funciones de la biblioteca estándar.
    /// Coloque el sufijo _ALU a todas las funciones que desarrolle.
    /// No use ni modifique otro archivo que no sea main.c. Será el que deberá entregar en formato comprimido con nombre "Apellido_Nombre_DNI.zip".
    EstadoAlumnoMateria alumno, alumnoEncontrado;
    Lista* pLectura=(*plAM)->sig;
    int mejorNota1,mejorNota2;
    while(pLectura != plAM)
    {
        verTope(pLectura,&alumno,sizeof(EstadoAlumnoMateria));
        alumnoEncontrado = buscarAlumno((*pLectura)->sig,alumno,sizeof(EstadoAlumnoMateria));
        if(alumno.dni == alumnoEncontrado.dni && alumno.materia == alumnoEncontrado.materia)
        {
            alumnoEncontrado.notaP1 = alumno.notaP1;
            alumnoEncontrado.notaP2 = alumno.notaP2;
            alumnoEncontrado.notaR1 = alumno.notaR1;
            alumnoEncontrado.notaR2 = alumno.notaR2;
            sacarDeLista(pLectura);
        }
        else
        {
            mejorNota1 = alumno.notaP1 > alumno.notaR1? alumno.notaP1 : alumno.notaR1;
            mejorNota2 = alumno.notaP2 > alumno.notaR2? alumno.notaP2 : alumno.notaR2;
            if(mejorNota1 >= 7 && mejorNota2 >= 7)
                alumno.condicion = PR;
            else if(mejorNota1 >= 4 && mejorNota2 >= 4)
                alumno.condicion = CU;
            else if(mejorNota1 >0 && mejorNota2 > 0)
                alumno.condicion = RE;
            else
                alumno.condicion = AU;

            pLectura = (*pLectura)->sig;
        }
    }
}

int sacarDeLista(Lista* plista)
{
    NodoD* nae = (*plista)->sig? (*plista)->sig : plista;
    if(!plista)
    {
        return 0;
    }

    if(nae == plista)
    {
        *plista = NULL;
    }
    else
    {
        (*plista)->sig = nae->sig;
    }

    free(nae->elem);
    free(nae);

    return 1;
}

EstadoAlumnoMateria buscarAlumno(Lista* plista,EstadoAlumnoMateria alumnoAEncontrar, size_t tamElem)
{
    EstadoAlumnoMateria alumno;
    verTope(plista,&alumno,tamElem);
    while(*plista && alumnoAEncontrar.dni != alumno.dni && alumnoAEncontrar.materia != alumno.materia)
    {
        plista = (*plista)->sig;
        verTope(plista,&alumno,tamElem);
    }
    return alumno;
}

int verTope(Lista* plista,void* elem, size_t tamElem)
{
    if(!plista)
        return 0;

    memcpy(elem,(*plista)->sig,min(tamElem,(*plista)->sig->tamElem));
    return 1;
}
