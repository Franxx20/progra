#ifndef COMPLEJO_H
#define COMPLEJO_H


class Complejo
{
	public:
		

	private:
};

#endif // COMPLEJO_H
