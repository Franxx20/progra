#include <stdio.h>
#include <stdlib.h>

/// Descomentar lo que corresponda. Si Recupera parcial 1: TDA_LISTA_IMPL_DINAMICA. Si es parcial 2: TDA_LISTA_IMPL_DINAMICA_DOBLE.
//#define TDA_LISTA_IMPL_DINAMICA
#define TDA_LISTA_IMPL_DINAMICA_DOBLE
#include "../TDALista/TDAlista.h"

#include "../SolucionAlumnos/SolucionAlumnos.h"

#define NOMBRE_ARCHIVO_NOTAS "Notas.dat"


int main()
{
	generarArchivo(NOMBRE_ARCHIVO_NOTAS);
	
	Lista listaAM;
	crearLista(&listaAM);
	
	cargarLista(&listaAM, NOMBRE_ARCHIVO_NOTAS);
	
	puts("Lista antes de procesar:");
	recorrerLista(&listaAM, mostrarEstadoAM, NULL);
	
	///procesarLista_ALU(&listaAM);
 	procesarLista(&listaAM);
	
	puts("\nLista despues de procesar:");
	recorrerLista(&listaAM, mostrarEstadoAM, NULL);
	
	return 0;
}


void procesarLista_ALU(Lista* plAM)
{
	/// Desarrolle esta función y todas las que invoque. Puede usar funciones de la biblioteca estándar.
	/// Coloque el sufijo _ALU a todas las funciones que desarrolle.
	/// No use ni modifique otro archivo que no sea main.c. Será el que deberá entregar en formato comprimido con nombre "Apellido_Nombre_DNI.zip".
}
