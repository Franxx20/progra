#include "../include/utilitarias.h"

void texto_a_nota(const char * cadena,t_nota * pnota){

}
