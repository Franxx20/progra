#ifndef EJERCICIO_2_H_INCLUDED
#define EJERCICIO_2_H_INCLUDED
#define ES_MAYUS(x) (x>='A' && x<='Z')

int mi_strlen(char *cad);
void mi_tolower(char* cad);
void borra_espacio(char *cad);
void borra_todos_espacios(char *cad);
int es_palindromo(char *cad);


#endif // EJERCICIO_2_H_INCLUDED
