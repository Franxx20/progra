#ifndef EJER2_H_INCLUDED
#define EJER2_H_INCLUDED

size_t mi_strlen(const char *cad);
char *mi_strstr(char * donde,const char * buscar);

#endif // EJER2_H_INCLUDED
