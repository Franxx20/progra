#ifndef CUENTA_H
#define CUENTA_H

typedef struct
{
	char cuenta[51];
	unsigned dniTitular;
	double saldo;
}
Cuenta;


#endif // CUENTA_H
