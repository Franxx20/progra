#ifndef FUNRES_H_INCLUDED
#define FUNRES_H_INCLUDED

#include "tipos.h"

int crearLotePrueba_alumn(const char* filename);
int generarInforme_alumn(const char* filename, const char* output, const tSector* secs);

#endif
