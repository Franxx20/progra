#ifndef RACIONAL_H
#define RACIONAL_H


class Racional
{

};

#endif // RACIONAL_H
