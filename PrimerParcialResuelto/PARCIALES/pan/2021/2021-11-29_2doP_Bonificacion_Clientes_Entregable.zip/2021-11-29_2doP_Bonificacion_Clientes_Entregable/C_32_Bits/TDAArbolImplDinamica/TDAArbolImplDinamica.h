#ifndef TDAARBOLIMPLDINAMICA_H
#define TDAARBOLIMPLDINAMICA_H

#include "../Nodo/NodoA.h"


typedef NodoA* Arbol;


#endif // TDAARBOLIMPLDINAMICA_H
