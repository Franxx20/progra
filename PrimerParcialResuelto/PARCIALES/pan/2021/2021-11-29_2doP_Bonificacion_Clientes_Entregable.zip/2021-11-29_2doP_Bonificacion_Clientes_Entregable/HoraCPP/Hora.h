#ifndef HORA_H
#define HORA_H

#include <iostream>

using namespace std;


class Hora
{

};


#endif // HORA_H
