/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* AC� NO DEBE HACER NINGUNA MODIFICACI�N                         *//**/
/**//**//*      S�LO PARA SUS PRUEBAS CON LOS DISTINTOS                   *//**/
/**//**//*      LOTES E INVOCAR A SUS FUNCIONES                           *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

#include "main.h"

int main()
{
    FILE   *fpPantalla;
    char    nomArch[300],
            comando[350];

#ifdef CODIGO_ALUMNO
    sprintf(nomArch, "pantalla%dx%d.txt", M_FILAS, N_COLUM);
#else
    sprintf(nomArch, "pantalla%dx%d_BIEN.txt", M_FILAS, N_COLUM);
#endif

    if((fpPantalla = fopen(nomArch, "wt")) == NULL)
        fpPantalla = stdout;


    punto_1(fpPantalla);


    fclose(fpPantalla);
    sprintf(comando, "start Notepad \"%s\"", nomArch);
    system(comando);
    return 0;
}


/**
 **
 **/
void punto_1(FILE *fpPantalla)
{
    int cant,
        matriz[M_FILAS][N_COLUM];

    fprintf(fpPantalla,
            "********************************************\n"
            "* PUNTO-1: comienza a ejecutarse.          *\n"
            "********************************************\n");
    cant = cargarMat(matriz, M_FILAS, N_COLUM);
    fprintf(fpPantalla,
            "Se cargaron %d elementos en la matriz.\n"
            "Se muestra la matriz de %d filas %d columnas.\n",
            cant, M_FILAS, N_COLUM);
    cant = mostrarMat(matriz, M_FILAS, N_COLUM, fpPantalla);
    fprintf(fpPantalla, "Se mostraron %d elementos.\n", cant);
    fprintf(fpPantalla, " - Punto 1 a.- Mostrando el 1er y 3er cuadrantes.\n");

#ifdef PUNTO_1_A
    cant = mostrar1erY3erCuadrante_MIO(matriz, M_FILAS, N_COLUM, fpPantalla);
#else
    cant = mostrar1erY3erCuadrante(matriz, M_FILAS, N_COLUM, fpPantalla);
#endif // PUNTO_1_A

    fprintf(fpPantalla,
            "Se mostraron %d elementos del 1er y 3er cuadrantes.\n",
            cant);

    fprintf(fpPantalla, " - Punto 1 b.- Mostrando el 2do y 4to cuadrantes.\n");

#ifdef PUNTO_1_B
    cant = mostrar2doY4toCuadrante_MIO(matriz, M_FILAS, N_COLUM, fpPantalla);
#else
    cant = mostrar2doY4toCuadrante(matriz, M_FILAS, N_COLUM, fpPantalla);
#endif // PUNTO_1_B

    fprintf(fpPantalla,
            "Se mostraron %d elementos del 2do y 4to cuadrantes.\n",
            cant);

    fprintf(fpPantalla, " - Punto 1 c.- Intercambiando elementos.\n");

#ifdef PUNTO_1_C
    cant = intercambiarElementos_MIO(matriz, M_FILAS, N_COLUM);
#else
    cant = intercambiarElementos(matriz, M_FILAS, N_COLUM);
#endif // PUNTO_1_C

    fprintf(fpPantalla, "Se intercambiaron %d pares de elementos.\n", cant);
    cant = mostrarMat(matriz, M_FILAS, N_COLUM, fpPantalla);
    fprintf(fpPantalla,
            "Se mostraron %d elementos de la matriz.\n",
            cant);
    fprintf(fpPantalla,
            "********************************************\n"
            "*           Fin ejecuci�n PUNTO-1          *\n"
            "********************************************\n\n");
}



