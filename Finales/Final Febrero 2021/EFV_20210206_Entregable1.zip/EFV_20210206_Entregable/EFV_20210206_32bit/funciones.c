/**//*        EN LOS SIGUIENTES MACROREEMPLAZOS INDIQUE:                  *//**/
/**//*    APELLIDO(S)     (COMPLETO)                                      *//**/
/**//*    NOMBRE(S)       (COMPLETO)                                      *//**/
/**//*    N�MERO DE DNI   (con los puntos de mill�n y de mil              *//**/
/**//*    COMISI�N                                                        *//**/
#define APELLIDO    "P�REZ DEL R�O"
#define NOMBRE      "Juan Manuel"
#define DOCUMENTO   "22.333.444"
#define COMISION    "07(2299)"
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
#undef APELLIDO
#undef NOMBRE
#undef DOCUMENTO
#undef COMISION
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* CUALQUIER INCLUDE DE BIBLIOTECA QUE NECESITE, H�GALO DESDE AC� *//**/



/**//**//* CUALQUIER INCLUDE DE BIBLIOTECA QUE NECESITE, H�GALO HASTA AC� *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
#include "funciones.h"
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* AC� DEBE DESARROLLAR LAS FUNCIONES Y PRIMITIVAS PEDIDAS    *//**//**/
/**//**//* ADEM�S DE CUALQUIER OTRA FUNCI�N QUE SE REQUIERA           *//**//**/

/** DESDE AC� NO VA EN EL "ENTREGABLE" (pero est�n sugeridas en el tema)     **/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/** PUNTO 1 A **/
int mostrar1erY3erCuadrante_MIO(int mat[][N_COLUM], int cantFil, int cantCol,
                                FILE *fpPantalla)
{
    int     cant = 0;

    return cant;
}

/** PUNTO 1 B **/
int mostrar2doY4toCuadrante_MIO(int mat[][N_COLUM], int cantFil, int cantCol,
                                FILE *fpPantalla)
{
    int     cant = 0;

    return cant;
}

/** PUNTO 1 C **/
int intercambiarElementos_MIO(int mat[][N_COLUM], int cantFil, int cantCol)
{
    int     cant = 0;

    return cant;
}

/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

