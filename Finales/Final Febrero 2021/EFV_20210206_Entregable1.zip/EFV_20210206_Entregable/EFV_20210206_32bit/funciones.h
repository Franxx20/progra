/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* CUALQUIER MODIFICACI�N QUE HAGA NO SER� TENIDA EN CUENTA.      *//**/
/**//**//* S�LO PARA CAMBIAR LAS CANTIDADES DE FILAS Y COLUMNAS           *//**/
/**//**//*      DURANTE SUS PRUEBAS                                       *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
#ifndef FUNCIONES_H_
#define FUNCIONES_H_

#include <stdio.h>

#include "quehice.h"

/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/** para el PUNTO_1 **/
#if   PRUEBA_NRO  ==  1
#define M_FILAS             9
#define N_COLUM             7
#elif PRUEBA_NRO  ==  2
#define M_FILAS             8
#define N_COLUM             10
#elif PRUEBA_NRO  ==  3
#define M_FILAS             11
#define N_COLUM             10
#endif // PRUEBA_NRO

/** funci�n de servicio **/
int cargarMat(int mat[][N_COLUM], int cantFil, int cantCol);
int mostrarMat(int mat[][N_COLUM], int cantFil, int cantCol, FILE *fpPantalla);

/** PUNTO 1 A **/
int mostrar1erY3erCuadrante(int mat[][N_COLUM], int cantFil, int cantCol,
                            FILE *fpPantalla);

int mostrar1erY3erCuadrante_MIO(int mat[][N_COLUM], int cantFil, int cantCol,
                                FILE *fpPantalla);


/** PUNTO 1 B **/
int mostrar2doY4toCuadrante(int mat[][N_COLUM], int cantFil, int cantCol,
                            FILE *fpPantalla);

int mostrar2doY4toCuadrante_MIO(int mat[][N_COLUM], int cantFil, int cantCol,
                                FILE *fpPantalla);

/** PUNTO 1 C **/
int intercambiarElementos(int mat[][N_COLUM], int cantFil, int cantCol);

int intercambiarElementos_MIO(int mat[][N_COLUM], int cantFil, int cantCol);

/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/


#endif

