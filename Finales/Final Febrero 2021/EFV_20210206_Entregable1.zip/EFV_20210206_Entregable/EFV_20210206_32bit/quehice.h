#ifndef QUEHICE_H_
#define QUEHICE_H_


///#define CODIGO_ALUMNO

#ifdef CODIGO_ALUMNO
///    #define PUNTO_1_A
///    #define PUNTO_1_B
///    #define PUNTO_1_C
#endif // CODIGO_ALUMNO


/// probar con 1  2  3
#define PRUEBA_NRO      1


#endif // QUEHICE_H_
