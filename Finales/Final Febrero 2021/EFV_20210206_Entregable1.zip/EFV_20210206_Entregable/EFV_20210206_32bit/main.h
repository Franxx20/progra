/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* AC� NO DEBE HACER NINGUNA MODIFICACI�N                         *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "funciones.h"
#include "quehice.h"



void punto_1(FILE *fpPantalla);

#endif

