
#include "../include/racional.h"

int Racional::absoluto(int n)
{
    if(signo(n))
        n = -n;
    return n;
}

char Racional::signo(int n)
{
    return n < 0 ? '-' : '\0';
}

int Racional::mcd(int a, int b)
{
    int resto = a % b;
    while(resto)
    {
        a = b;
        b = resto;
        resto = a % b;
    }
    return absoluto(b);
}

Racional::Racional(int nume, int deno)
{
    if(signo(deno))
    {
        nume = -nume;
        deno = -deno;
    }
    int divisor = mcd(nume, deno);
    this->nume = nume / divisor;
    this->deno = deno / divisor;
}

ostream &operator <<(ostream &salida, Racional racio)
{
    cout << racio.nume << '/' << racio.deno;
    return salida;
}

int Racional::getNumerador()
{
    return nume;
}

int Racional::getDenominador()
{
    return deno;
}

int Racional::enteroMasCercano()
{
    return float(nume) / deno + .5;
}

void Racional::mostrarEnteroYFraccion(Racional r)
{
    int     enteros = r.nume / r.deno;
    cout << enteros << " " << r.nume % enteros << '/' << r.deno;
}

Racional Racional::operator++()
{
    nume += deno;
    return *this;
}

