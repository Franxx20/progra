
#include "../include/main.h"


int main()
{
    int         nume = 36,
                deno = 32;

    cout << "creando objeto racional con " << nume << " y " << deno << endl;

    Racional    r1(nume, deno);

    operarConRacional(r1);

    nume = 66;
    deno = 54;

    cout << "creando objeto racional con " << nume << " y " << deno << endl;
    Racional    r2(nume, deno);

    operarConRacional(r2);

    return 0;
}

void operarConRacional(Racional racio)
{
    cout << "Racional r1 = " << racio << endl;
    cout << " - Numerador = " << racio.getNumerador() << endl <<
            " - Denominador = " << racio.getDenominador() << endl <<
            " - Entero mas cercano = " << racio.enteroMasCercano() << endl <<
            " - entero + fraccion = ";
    Racional().mostrarEnteroYFraccion(racio);
    cout << endl;
    cout << " - ++racio = " << ++racio << endl << endl;
}

