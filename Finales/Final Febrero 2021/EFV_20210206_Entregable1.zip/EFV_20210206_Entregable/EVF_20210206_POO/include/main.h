#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

using namespace std;

#include <iostream>

#include "racional.h"


void operarConRacional(Racional r1);


#endif // MAIN_H_INCLUDED
