
#ifndef MAIN_H__
#define MAIN_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ARCH_ENT    "log.txt"
#define ARCH_SAL    "log_ordPLD.txt"
#define ARCH_MAL    "malPLD.txt"

#define     FILAS           50
#define     COLUM           30


#include "funciones.h"


#endif
