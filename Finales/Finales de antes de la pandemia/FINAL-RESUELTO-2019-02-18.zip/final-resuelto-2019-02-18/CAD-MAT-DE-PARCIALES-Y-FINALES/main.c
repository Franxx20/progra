#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 4
#define TAM2 5
void matriz_triangulo_superior(int mat[][TAM]);
void triangulo_derecha(int mat[][TAM]);
void triangulo_izq(int mat[][TAM]);
void triangulo_x(int mat [][TAM]);/**TOMADA POR RENATA 1ER PARCIAL*/
void triangulo_inf(int mat[][4]);
void transponer_matriz(int mat [][4]);
void multiplicar_matriz(int mat1[][TAM],int mat2[][TAM]);
void sub_matriz(int mat[][TAM+1],int x,int y);/**RECUPERATORIO*/
void transponer_matriz_desde_centro(int mat[][4]);

char *mistrcat(char*s1, const char *s2);
char *mistrchr(char *s, int c);
int mistrcmp(const char *s1, const char *s2);
int mistrcoll(const char *s1, const char *s2);
char *mistrcpy(char *s1, const char *s2);
int mistrcspn(const char *s1, const char *s2);
int mistrlen(const char *s);
char *mistrstr(const char *s1, const char *s2);
int tolower(int ch);
int toupper(int ch);
int miatoi(const char *numPtr);
void miitoa( int,char  *,int base);
int micontarocurrenciascaracter(char *s, char *c);
char  *midarvuelta(char* );
char * micodificarcadena(char *,int);
char *strpbrk(const char *s1, const char *s2);

/**CADENAS QUE  TOMARON EN PARCIALES**/
char *minormalizar(char *s1);
int micontarocurrenciaspalabra(char *s,  char *c);
int my_atoi(const char* pointer);
char *reemplzar_cadena_por_otra(char *, char *, char *);
char *mistrcat_al_reves(char* s1, const char* s2);
int contar_con_n_o_mas_vocales(char *s,int vocales);
char * minormalizar_final(char* s1);
char *comprimir_cadena(char * s);
void anagrama(char *, char *);/**DEFINICION DE ANAGRAMA: una palabra o frase que resulta de la transposici�n 
de letras de otra palabra o frase. Dicho de otra forma, una palabra es anagrama de otra si las 
dos tienen las mismas letras, con el mismo n�mero de apariciones, pero en un orden diferente.
ejemplos:
alan smithee -> the alias -}+?�04987123   men
mary -> army
nacionalista -> altisonancia

mis 2 formas de hacer esta cadena si queres hacerla vos aca deja de leer :v







hay 2 formas de pensarlo-> con tda cola pila lista  o recorrer cadena adelante y hacia atras ejemplo de alan
es ir poniendo en lista las letras que ya recorriste de la primera cadena por ejemplo que en lista este a-l y estes apuntando a la
segunda a de alan  seria recorrer la lista y comparar con el puntero donde estas actualmente si ya existia avanzar a la siguiente letra 
si no pones en lista

o la segunda forma de pensarlo es cuando estes en la 2da a de alan recorrer con un puntero aux desde donde estas para atras a ver
si esa letra ya la habias comparado y si es verdad pasar a la siguiente letra

*/


/*int matriz[TAM][TAM]={
   {1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}
   };
   int matriz2[TAM][TAM]={
   {1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}
   };
   triangulo_x(matriz);
   puts("\n");
   triangulo_derecha(matriz);
   puts("\n");
   triangulo_izq(matriz);
   puts("\n");
   matriz_triangulo_superior(matriz);
       puts("\n");
   triangulo_inf(matriz);
           puts("\n");
   transponer_matriz(matriz);
           puts("\n");
       multiplicar_matriz(matriz,matriz2);



       int matriz[TAM+1][TAM+1]={
   {1,2,3,4,5},{5,6,7,8,5},{9,10,11,12,5},{13,14,15,16,5},{1,2,3,4,5}
   };
   int x=1;
   int y=1;
   sub_matriz(matriz,x,y);
  */
int main()
{
    char cad1[50]="nacionalista";
    char cad2[20]="altisonancia";
    //char cad3[40]="ABCDEFG";
    // char cad3[60]=" *-+_-pTE.    saENZ �+**}}__- ,?�76  pEnA  28   A  ";
//  char caracter='?';
    // printf("%s",mistrcat(cad1,cad2));
    // printf("%s",mistrchr(cad1,caracter));
    //  printf("%s",midarvuelta(cad1));
    //printf("%s",strstr(cad1,"la"));
    //char aux[5]="1236";
// int dato=miatoi(aux);
    //printf("%d",dato);
    //printf("%s",minormalizar(cad3));
    /*char cad1[150]="�Desarrolle una funci�n que realice, dentro de una cadena, el reemplazo de todas las ocurrencias de una subcadena por otra�";
    char cad2[7]="string";
    char cad3[7]="cadena";
    printf("%s\n",cad1);
    printf("\n%s",reemplzar_cadena_por_otra(cad1,cad3,cad2));
    */
    // mistrcat_al_reves(cad1,cad2);
    // printf("%s",cad1);

    // comprimir_cadena(cad3);
    //printf("%s\n\n",cad3);
    //  printf("cant:%d",micontarocurrenciaspalabra(cad1,cad2));
 //   reemplzar_cadena_por_otra(cad1,cad2,cad3);
   // printf("%s",cad1);
    anagrama(cad1,cad2);


    return 0;
}
char * minormalizar_final(char* s)
{
    char *aux=s,*ini=s;
    int band=0,poner_espacios=0;
    while(*aux!='\0')
    {
        if( (*aux>='A'&& *aux<='Z') || (*aux>='a'&& *aux<='z') )
        {
            
            if( band==0 &&(*aux>='a'&& *aux<='z'))
            {
                *aux-=32;
            }
           else if((*aux>='A'&& *aux<='Z')&&band!=0)
            {
                *aux+=32; 
            }
            *s=*aux;
            poner_espacios=0;
            band=1;
            s++;

        }
        else
        {
            if(poner_espacios==0)
            {
                *s=';';
                s++;
            }
            poner_espacios=1;
            
        }
        
        
        aux++;
    }
    *s='\0';
    return ini;
}

int contar_con_n_o_mas_vocales(char* s, int vocales)
{
    int cantpalabras=0,cant_vocales=0,band=0;
    while(*s!='\0')
    {
        if( (*s>='A'&& *s<='Z') || (*s>='a'&& *s<='z') )
        {
            if( *s=='a'|| *s=='e' || *s=='i' ||*s=='o'||*s=='u'||*s=='A'|| *s=='E' || *s=='I' ||*s=='O'||*s=='U')
            {
                cant_vocales++;
            }
            if(cant_vocales>=vocales&&band!=1)
            {      band=1;
                cantpalabras++;
            }
        }
        else
        {
                cant_vocales=0;
                band=0;    
        }
        
        s++;
    }
    
    return cantpalabras;
}
void anagrama( char *palabra1,char * palabra2)
{
    int cant_de_repeticiones_de_la_letra_en_cad1=0,cant_de_repeticiones_de_la_letra_en_cad2=0;
    char *aux=palabra1;
    char *comparar_atras=palabra1;
    char *auxpalabra2=palabra2;
    int i=0,letras_avanzadas=0,band=0;/**saber cuantas letras avanze*/
    while(*palabra1!='\0')
    {
        band=0;
        aux=palabra1;
        comparar_atras=palabra1;
        comparar_atras--;
        /***pregunto si a esa letra ya la habia comparado anteriormente si es verdadero avanzo a sig letra*/
        for(i=0;i<letras_avanzadas;i++)
        {
            if(*comparar_atras==*palabra1)
            {
                palabra1++;
                band=1;
            }
            else
            {
                comparar_atras--;
            }
            
        }
                /**fin de comparacion de letras anteriores***/
                
        while(band!=1&&*auxpalabra2!='\0')
        {
            if(*aux!='\0'&&(*palabra1)==*aux)
            cant_de_repeticiones_de_la_letra_en_cad1++;/**sumo cant de apariciones de la letra en toda la cadena**/
            if(*palabra1==*auxpalabra2)
            cant_de_repeticiones_de_la_letra_en_cad2++;/**sumo cant de apariciones de la letra en toda la cadena2**/
            aux++;
            auxpalabra2++;
        }
        /**si es una letra  y la cant de cad1 != cant de cad2 entonces no es anagrama*/
        if( ( (*palabra1>='A'&&*palabra1<='Z')|| (*palabra1>='a'&&*palabra1<='z') ) && cant_de_repeticiones_de_la_letra_en_cad1!=cant_de_repeticiones_de_la_letra_en_cad2)
        {
            printf("NO ES ANAGRAMA\n");
            return;
        }
        else/**seteo datos*/
        {
            cant_de_repeticiones_de_la_letra_en_cad1=0;
            cant_de_repeticiones_de_la_letra_en_cad2=0;
            auxpalabra2=palabra2;
        }
      letras_avanzadas++;/**cuantas letras avanze para irme hacia atras*/
      if(band!=1)/**avanzo o no dependiendo si la letra que compare ya estaba anteriormente**/
      palabra1++;  
    }
    printf("ES ANAGRAMA");
    
    
}

int micontarocurrenciaspalabra(char* s,  char* c)
{
    int cant=0;
    char *aux_palabra_larga,*buscar;
    while(*s!='\0')
    {
        aux_palabra_larga=s;
        buscar=c;

        while((*aux_palabra_larga==*buscar)&&(*buscar!='\0'))
        {
            buscar++;
            aux_palabra_larga++;
        }


        if(*buscar=='\0')
            cant++;

        s++;
    }
    return cant;
}
char * comprimir_cadena(char* s)
{
    int cant=0,tamanio_de_desplazar=0,i;
    char    * aux=s,*recorrer=s;
    char   *ant=s,*desplazar;
    while(*aux!='\0')
    {
        ant=aux;
        while(*aux==*ant&&*aux!='\0')
        {
            cant++;
            aux++;
        }
        *recorrer=*(aux-1);
        recorrer++;
        if(cant>1)
        {
            *recorrer=cant+'0';
            recorrer++;
        }
        else if(cant==1)
        {
            /**********FUNCION DESPLAZAR CADENA*********/
            desplazar=aux;
            while(*aux!='\0')
            {
                tamanio_de_desplazar++;
                aux++;
                desplazar++;
            }
            aux--;
            for(i=0; i<tamanio_de_desplazar; i++)
            {
                *desplazar=*aux;
                desplazar--;
                aux--;
            }
            *(desplazar+tamanio_de_desplazar+1)='\0';
            /**********FIN DE FUNCION DESPLAZAR****/
            tamanio_de_desplazar=0;
            aux++;
            *recorrer=1+'0';
            aux++;
            recorrer++;

        }

        cant=0;
    }
    *recorrer='\0';


    return s;
}

char *mistrcat_al_reves(char* s1, const char* s2)
{
    int tam=strlen(s1);
    int tam2=strlen(s2);
    int veces=0;
    int diferencia=tam+(tam2-tam);
    int i=tam;
    char *ini=s1;
    char *ini2=s1;
    char *aux=s1;
    while(*aux!='\0')
        aux++;
    while(veces<tam2)
    {
        if(i>diferencia)
        {

            *aux=*ini;
            aux++;
            ini++;
            veces++;
        }
        else
        {
            *aux=' ';
            aux++;
        }
        i++;
    }
    *aux='\0';
    while(*s2!='\0')
    {
        *ini2=*s2;
        ini2++;
        s2++;
    }
    return s1;
}

char *reemplzar_cadena_por_otra(char *s1,  char *reemplazo, char *s2)
{
    char *donde_reemplazar=s1,*cadena_a_buscar=reemplazo,*cadena_a_reemplazar=s2;
    char *desplazar,*ant;

    int saber_tamanio=0,diferencia=0;
    int i,j;

    while(*s1!='\0')
    {
        donde_reemplazar=s1;
        cadena_a_reemplazar=s2;

        while(*donde_reemplazar==*cadena_a_buscar)
        {
            donde_reemplazar++;
            cadena_a_buscar++;
            saber_tamanio++;
        }

        if(*cadena_a_buscar=='\0')
        {
            if(saber_tamanio==strlen(cadena_a_reemplazar))/**si son iguales en tamanio directamente reemplazo ej:cadena - string **/
            {


                while(*cadena_a_reemplazar!='\0')
                {
                    *s1=*cadena_a_reemplazar;
                    s1++;
                    cadena_a_reemplazar++;
                }
                s1--;
            }
            else if( saber_tamanio >strlen(cadena_a_reemplazar) )
            {

                while(*cadena_a_reemplazar!='\0')
                {
                    *s1=*cadena_a_reemplazar;
                    s1++;
                    cadena_a_reemplazar++;
                    diferencia++;/**tamanio de cadena mas chica*/
                }
                /**ej : HOLA por hi me queda  hila entonces seteo con espacio y queda hi__ siguiente palabra */
                for(i=diferencia; i<saber_tamanio; i++)/**de tamanio de cadena mas chica 2 hasta 4 entonces pongo 2 lugares con blanco*/
                {
                    *s1=' ';/**seteo los campos sobrantes con un espacio*/
                    s1++;
                }
                s1--;


            }
            else
            {
                /**************** FUNCION DESPLAZAR CADENA TAM LUGARES HACIA ADELANTE**************************************/
                
                /**LA LOGICA PARA DESPLAZAR ES IRSE HASTA EL FINAL DE LA CADENA Y EMPEZAR DESDE EL '\0' A MOVER LOS LUGARES QUE QUIERAS EJ:
                HOLA'\0' Y QUIERO MOVERLA 2 LUGARES A LA DERECHA POR CADENA A REEMPLAZAR SERIA
                1 PASADA= HHOLA'\0'
                2 PASADA HHHOLA'\0'
                Y LOS PRIMEROS 2 LUGARES PUEDO PONERLO CON UN ESPACIO ' '
                O DIRECTAMENTE REEMPLAZAR LA CADENA RESULTANTE QUE ES LO QUE HICE HHHOLANAHUEL->ABCDFGNAHUEL
                */
                while(*donde_reemplazar!='\0')
                {
                    diferencia++;/**SE CUANTOS LUGARES ME FALTAN HASTA FIN DE CADENA*/
                    donde_reemplazar++;
                }
                ant=donde_reemplazar;/**LO USO PARA SETEAR EL LUGAR*/
                desplazar=donde_reemplazar;
                desplazar--;/**UNO ANTES DE BARRA '0' SIEMPRE ESTA PARA DESPLAZAR EL CONTENIDO OSEA EN LA A DE HOLA'\0'*/
                for(j=1; j<=(strlen(s2)-saber_tamanio); j++)/**CUANTOS LUGARES TENGO DE QUE DESPLAZAR SEGUN TAMANIO DE CAD 2*/
                {

                    /** ME VOY DESPLAZANDO DE A 1 LUGAR A LA VES**/
                    for(i=0; i<diferencia; i++)
                    {
                        *donde_reemplazar=*desplazar;
                        donde_reemplazar--;
                        desplazar--;
                    }
                    *(donde_reemplazar+diferencia+1)='\0';
                    desplazar=donde_reemplazar=ant;
                    donde_reemplazar+=j;
                    desplazar+=j-1;


                }
                /********************** FIN DE DESPLAZAMIENTO DE CADENA***********************************/
                /**EJ: HOLANAHUEL POR ABCDFG -> HOLANNNAHUEL Y DESPUES ABCDFGNAHUEL**/
                while(*cadena_a_reemplazar!='\0')
                {
                    *s1=*cadena_a_reemplazar;
                    s1++;
                    cadena_a_reemplazar++;
                }
                s1--;



            }


        }
        diferencia=0;
        saber_tamanio=0;
        cadena_a_buscar=reemplazo;


        s1++;
    }


    return s1;
}

char * minormalizar(char* s1)
{
    int band=0;
    int agregar_blanco=1;
    char *aux=s1;
    char *cadbien=s1;
    while(*aux!='\0')
    {
        if( (*aux>='a'&&*aux<='z') ||  ( (*aux) >='A'&& (*aux)<='Z'  ) )
        {
            if(band==0)/**si es primera letra en minuscula la paso a mayuscula*/
            {
                band=1;
                if(*aux>='a'&&*aux<='z')
                    *aux-=32;
            }
            else
            {
                if( *aux >='A'&& *aux <= 'Z')
                    *(aux)+=32;
            }
            *cadbien=*aux;
            cadbien++;
            agregar_blanco=0;
        }
        else
        {
            if(agregar_blanco==0)
            {

                *cadbien=' ';
                cadbien++;
                agregar_blanco=1;
            }
        }



        aux++;
    }
    *(cadbien)='\0';

    return s1;
}
int miatoi(const char *numPtr)
{
    int num=0;
    char *aux=(char*)numPtr;
    while(*aux!='\0')
    {
        num=num*10+(int)(*aux)-'0';
        aux++;
    }
    return num;
}
void miitoa( int  num,char  * cad,int base)
{
    char* ini=cad;
    while(num>0)
    {
        *ini=(num%base)+'0';
        num=num/base;
        ini++;
    }
    *ini='\0';

}

char *mistrstr(const char *s1, const char *s2)
{
    char *aux=(char*)s1;
    char *aux2=(char*)s2;
    int palabra=strlen(s2);
    int aciertos=0;
    while(*aux!='\0')
    {
        if(*aux==*aux2)
        {
            aux++;
            aux2++;
            aciertos++;
            if(palabra==aciertos)
                return aux;
        }
        else
        {
            aux2=(char*)s2;
            aciertos=0;
        }

        aux++;
    }
    return NULL;
}

char  *midarvuelta(char* s )
{
    char* fin=s;
    char *ini=s;
    char aux;
    int cant=(strlen(s)/2);
    while(*fin!='\0')
        fin++;
    fin--;
    while(*ini!='\0'&&cant>=0)
    {
        aux=*ini;
        *ini=*fin;
        *fin=aux;
        fin--;
        ini++;
        cant--;
    }

    return s;
}
char *mistrchr(char *s, int c)
{
    while(*s!='\0')
    {
        if(*s==c)
            return s;
        s++;
    }

    return NULL;
}
char *mistrcat(char*s1, const char *s2)
{
    char *aux=s1;
    char *aux2=(char*)s2;

    while(*aux!='\0')
        aux++;

    while(*aux2!='\0')
    {
        *aux=*aux2;
        aux++;
        aux2++;
    }
    *aux='\0';
    return s1;
}


void triangulo_x(int mat[][4])
{
    int i,j;

    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            if((mat[i][i]==mat[i][j])||(i+j)==TAM-1)
                printf(" %d ",mat[i][j]);
            else
                printf(" - ");
        }
        printf("\n");
    }

}
void triangulo_derecha(int mat[][4])
{

    int i,j;

    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            if((i+i)<=(i+j)&&(i+j)>=TAM-1)
                printf(" %d ",mat[i][j]);
            else
                printf(" - ");
        }
        printf("\n");
    }



}
void triangulo_izq(int mat[][4])
{

    int i,j;

    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            if((i+i)>=(i+j)&&(i+j)<=TAM-1)
                printf(" %d ",mat[i][j]);
            else
                printf(" - ");
        }
        printf("\n");
    }



}
void matriz_triangulo_superior(int mat[][4])
{

    int i,j;

    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            if((i+i)<=(i+j)&&(i+j)<=TAM-1)
                printf(" %d ",mat[i][j]);
            else
                printf(" - ");
        }
        printf("\n");
    }



}
void triangulo_inf(int mat[][4])
{

    int i,j;

    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            if((i+i)>=(i+j)&&(i+j)>=TAM-1)
                printf(" %d ",mat[i][j]);
            else
                printf(" - ");
        }
        printf("\n");
    }



}
void transponer_matriz(int mat[][4])
{
    int aux,i,j;
    for(i=0; i<TAM; i++)
    {
        for(j=i; j<TAM; j++)
        {
            aux=mat[i][j];
            mat[i][j]=mat[j][i];
            mat[j][i]=aux;
        }

    }

    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            printf("%d-",mat[i][j]);
        }
        printf("\n");
    }

}
void multiplicar_matriz(int mat1[][4], int mat2[][4])
{
    int i,j,z;
    int aux[TAM][TAM]=
    {
        {0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}
    };
    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            for(z=0; z<TAM; z++)
            {
                aux[i][j]+=mat1[i][z]*mat2[z][j];
            }
        }

    }

    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            printf("%d-",aux[i][j]);
        }
        printf("\n");
    }


}
/* x=1 y=1
1 2 3 4 5
1 4 3 7 5
1 9 3 9 5
1 8 7 8 5
1 2 3 4 5
*/
//resultado  desde el centro irte a la izq y der segun x e y
/*
 4 3 7
 9 3 9
 8 7 8
*/

// medio =((tam*tam)/2)+1
// vertice izq_sup=medio-x+y;
// vertice der_sup=medio+x+y;
// vertice izq_sup=medio-x-y;
// vertice izq_sup=medio+x-y;
/// 10 filas x 12 columnas   -> x=4  y =4
void sub_matriz(int mat[][5], int x, int y)
{
    int medio=((TAM2*TAM2)/2)+1;
    int vertice_izq_sup=medio-TAM2-1;
    int vertice_der_sup=medio-TAM2+1;
    int vertice_izq_inf=medio+TAM2-1;
    //int vertice_der_inf=medio+TAM2+1;/** para orientarse no hace falta*/
    int i,j,cont=0;
    for(i=0; i<TAM2; i++)
    {
        for(j=0; j<TAM2; j++)
        {
            printf("%d-",mat[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    printf("\n");
    printf("\n");

    int cambiar=0;/**para saber donde empieza sub matriz y empezar a cambiar */
    for(i=0; i<TAM2; i++)
    {
        for(j=0; j<TAM2; j++)
        {
            cont++;
            if(  ( cont >=(vertice_izq_sup) )&& ( cont <=(vertice_der_sup)) )
            {
                printf(" %-d ",mat[i][j]);
                cambiar=1;
            }
            else
                printf(" - ");

        }

        if(cambiar==1 && vertice_izq_sup< vertice_izq_inf)
        {
            vertice_izq_sup+=TAM2;
            vertice_der_sup+=TAM2;
            cambiar=0;
        }

        printf("\n");
    }

}
/*
 1 2 3  9 8 7
 4 5 6  6 5 4
 7 8 9  3 2 1
*/
void transponer_matriz_desde_centro(int mat[][4])
{
    int centro=(TAM*TAM)/2;
    int i,j,cant=0,cambio;

    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            printf("%d-",mat[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            cant++;
            if(cant<=centro)
            {
                cambio=mat[i][j];
                mat[i][j]= mat[TAM-i-1][TAM-j-1] ;
                mat[TAM-i-1][TAM-j-1]=cambio;
            }

        }


    }


    for(i=0; i<TAM; i++)
    {
        for(j=0; j<TAM; j++)
        {
            printf("%d-",mat[i][j]);
        }
        printf("\n");
    }

}
