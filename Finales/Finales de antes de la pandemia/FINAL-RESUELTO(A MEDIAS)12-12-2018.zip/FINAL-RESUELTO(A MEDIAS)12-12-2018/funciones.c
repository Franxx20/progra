#include "funciones.h"

/** desarrolle ac� las funciones que resuelven el problema planteado sin _ 2*/
void crearListaD(tListaD *p)
{
    *p=NULL;
}


int leerDecodificarYContabilizar(FILE *fpEnt, FILE *fpSal, tListaD *lista)
{
    char linea[500];
    char *aux,*cadenabien,*reemplazo,temporal;
    int par_o_no_par=0;
    int i,diferencia=0;
    tInfo dato;
    dato.veces=0;
    while(fgets(linea,500,fpEnt))
    {
        aux=linea;
        reemplazo=aux;
        while(*aux!='\0')
        {


            while(*aux!='\0' && ((*aux>='A'&&*aux<='Z')||(*aux>='a'&&*aux<='z') ) )
            {
                par_o_no_par++;
                aux++;
            }
            if( par_o_no_par!=0 && (par_o_no_par%2) ==0)
            {
                cadenabien=aux;
                cadenabien--;
                reemplazo=(aux-par_o_no_par);
                for(i=0; i<(par_o_no_par)/2; i++)
                {
                    temporal=*reemplazo;
                    *reemplazo=*cadenabien;
                    *cadenabien=temporal;
                    reemplazo++;
                    cadenabien--;
                }
                cadenabien=(aux-par_o_no_par);
                for(i=1; i<par_o_no_par+1; i++)
                {
                    *cadenabien-=i;
                    if(*cadenabien<'A')
                    {

                        diferencia='A'-*cadenabien;
                        *cadenabien='z'-diferencia+1;
                    }
                    
                    dato.palabra[i-1]=*cadenabien;
                    cadenabien++;
                }
                dato.palabra[i-1]='\0';



            }
            else if(par_o_no_par!=0)
            {

                cadenabien=(aux-par_o_no_par);
                for(i=1; i<par_o_no_par+1; i++)
                {
                    *cadenabien-=i;
                    if(*cadenabien<'A')
                    {

                        diferencia='A'-*cadenabien;
                        *cadenabien='z'-diferencia+1;
                    }
                   
                    cadenabien++;
                }
            
                cadenabien--;
                reemplazo=(aux-par_o_no_par);
                for(i=0; i<(par_o_no_par)/2; i++)
                {
                    temporal=*reemplazo;
                    *reemplazo=*cadenabien;
                    *cadenabien=temporal;
                    reemplazo++;
                    cadenabien--;
                }
                
                
                
            }
            if(*lista!=NULL&&(strcmp(dato.palabra,(*lista)->info.palabra))==0&&((*(aux-1)>='A'&&*(aux-1)<='Z')||(*(aux-1)>='a'&&*(aux-1)<='z') ))
            {
                dato.veces++;
            }
            
            insertarEnOrdenOAcumular_2(lista,&dato,compXClave,acumular_2);
             dato.veces=1;
            aux++;
            par_o_no_par=0;
        }
        fprintf(fpSal,"%s",linea);
            dato.palabra[0]='|';
       
    }
    
    while(sacarPrimero_2(lista,&dato))
    {
        if(dato.veces>=3)
        printf("\npalabra     %s:   cant:%d",dato.palabra,dato.veces);
    }
    printf("\n\n\n");
    
    return 0;
}
int sacarPrimero(tListaD* p, tInfo* d)
{
    return 1;
}
int insertarEnOrdenOAcumular(tListaD *p, const tInfo *d,
                             int (*comp)(const tInfo *d1, const tInfo *d2),
                             void (*acum)(tInfo *d1, const tInfo *d2))
{
    
    
    
    
    
    return TODO_BIEN;
}

int compXClave(const tInfo *d1, const tInfo *d2)
{
    return strcmp(d1->palabra,d2->palabra);
}

void invert(char *ini, char *fin)
{
    while(ini<fin)
    {
        *fin = *ini;
        ini++;
        fin--;
    }
}

void decodificarLinea(char *linea, tListaD *lista)
{
    ///es relevante si es par o impar?

}



