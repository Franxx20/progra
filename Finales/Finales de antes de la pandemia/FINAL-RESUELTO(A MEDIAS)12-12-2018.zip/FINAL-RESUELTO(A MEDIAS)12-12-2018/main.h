
#ifndef MAIN_H__
#define MAIN_H__

#define ARCH_ENT    "codific.txt"
#define ARCH_SAL    "decod.txt"

#define     FILAS           50
#define     COLUM           30


#include "funciones.h"


#endif
