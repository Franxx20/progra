#include <stdio.h>
#include <stdlib.h>

#include "main.h"
#include "funciones.h"

#include <math.h>




///** funciones a desarrollar
/*void multiplicar(int m[][CO_FI], int n[][CO], int r[][CO])
{

}*/


void multiplicar(int m[][CO_FI], int n[][CO], int r[][CO])
{
    int i,j,k;
    for(i=0; i<FI; i++)
    {

        for(j=0; j<CO; j++)
        {
            r[i][j]=0;
            for(k=0; k<CO_FI; k++)
            {
                r[i][j]+=m[i][k]*n[k][j];
            }

        }


    }


}
int esIdentidad(int m[][CO])
{

    int i,j,cont=0;
    for(i=0; i<CO; i++)
    {

        for(j=0; j<CO; j++)
        {
            if( m[i][i]!=0 && m[i][j]==m[j][i])
                cont++;


        }


    }
    if(cont==CO*CO)
        return 1;
    return 0;

}


/*
    int i,j,cont=0;
    for(i=0; i<CO; i++)
    {
        for(j=0; j<CO; j++)
        {
            if(m[i][i]==1)
            {
                cont++;
            }
            else if(m[i][j]==0)
            {
                cont++;
            }
            printf("%d",m[i][j]);
        }

        printf("\n");
    }
    if(cont==CO*CO)
        printf("\nes identidad\n");
    else
        printf("\nno es identidad\n");

  return 1;
  */

/**ESTA FUNCION ES UN BARDO*/
int  eliminarUnicos(t_lista *p)
{
    t_nodo *unico,*ant,*act,*lista,*aux,*saber_si_habia_anterior;
    int cant=0;
    if(*p!=NULL)
    {
        lista=*p;
        ant=NULL;
        while(lista->sig!=NULL)
        {
            unico=NULL;
            act=lista->sig;
            saber_si_habia_anterior=*p;
            while(act!=NULL&&unico==NULL)
            {
                    if((strcmp(act->info.codigo,lista->info.codigo))==0)    
                    {
                        unico=act;
                    }
                    else
                    {
                        act=act->sig;
                    }
            }
            
            while( saber_si_habia_anterior!=NULL&&(strcmp(saber_si_habia_anterior->info.codigo,lista->info.codigo))!=0&&saber_si_habia_anterior->sig!=lista)
            {
                    saber_si_habia_anterior=saber_si_habia_anterior->sig;
            }
            if((strcmp(saber_si_habia_anterior->info.codigo,lista->info.codigo))==0&&saber_si_habia_anterior!=lista)
            unico=saber_si_habia_anterior;
            if(unico!=NULL)
            {   
                ant=lista;
                lista=lista->sig;
            
            }else
            {
             
                if(ant==NULL)
                {
                    aux=lista;
                    lista=aux->sig;
                    free(aux);
                    *p=lista;
                    saber_si_habia_anterior=*p;
                                    cant++;

                }
                else if(ant!=NULL)
                {
                    ant->sig=lista->sig;
                    aux=lista;
                    lista=aux->sig;
                    free(aux);
                            cant++;

                }
                else
                lista=lista->sig;
            }
        }
        
    }
    return cant;
}

/*int esAVL(const t_arbol *p)
{

}*/

int es_AVL( t_arbol *pa)
{
    if( (saber_si_es_avl(&(*pa))) ==  contar_nodos ( &(*pa)) )
        return 1;
    return 0;
}
int saber_si_es_avl(t_arbol* pa)
{
    if( (*pa)!=NULL && abs(alturaArbol(&(*pa)->izq)-alturaArbol(&(*pa)->der))<=1)
    return saber_si_es_avl(&(*pa)->izq)+saber_si_es_avl(&(*pa)->der)+1;
    return 0;
}
int alturaArbol(t_arbol *pa)
{
    int hi,hd;
    if(*pa!=NULL)
    {
        hi=alturaArbol(&(*pa)->izq);
        hd=alturaArbol(&(*pa)->der);
        return hi>hd?hi+1:hd+1;
    }
    return 0;
 
}
int contar_nodos ( t_arbol * pa)
{
    if(*pa!=NULL)
    {
        return contar_nodos(&(*pa)->izq)+contar_nodos(&(*pa)->der)+1;
    }
    return 0;
}
