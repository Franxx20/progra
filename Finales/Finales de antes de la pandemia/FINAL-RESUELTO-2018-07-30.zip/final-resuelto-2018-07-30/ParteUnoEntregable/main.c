#include <stdio.h>
#include <stdlib.h>

#include "main.h"
#include "funciones.h"


int main()
{
   prodMat();

   mat1_b();

   lista();

   arbol();

   return 0;
}


void prodMat(void)
{
   int m[FI][CO_FI] = { {  2,  3, -5 },
                        {  7, -5, -4 } },
       n[CO_FI][CO] = { { -3, -6,  8,  2 },
                        {  2,  8, -6, -3 },
                        {  0,  4,  9, -8 } },
       r[FI][CO];


   mostrar("Matriz multiplicando", m[0], FI, CO_FI);
   mostrar("Matriz multiplicador", n[0], CO_FI, CO);

   ///multiplicar_2(m, n, r);  ///  <-- reemplazar por su propia versi�n
    multiplicar(m,n,r);
   mostrar("Matriz resultado", r[0], FI, CO);


}


void mat1_b(void)
{
   int s[CO][CO] = { {  1,  0,  0,  0 },
                     {  0,  1,  0,  0 },
                     {  0,  0,  1,  0 },
                     {  0,  0,  0,  1 } };

   if(esIdentidad(s))     ///  <-- reemplazar por su propia versi�n
      mostrar("La matriz es una matriz identidad", s[0], CO, CO);

   s[2][3] = -9;

   if(!esIdentidad(s))
      mostrar("La matriz NO es una matriz identidad", s[0], CO, CO);
}


void lista(void)
{
   t_lista  lista;
   int      elim;

   crearListaYCargar(&lista);
   puts("La lista contiene");
   mostrarLista(&lista);

   elim = eliminarUnicos(&lista);  ///  <-- reemplazar por su propia versi�n

   printf("Se eliminaron %d nodos.\nEstos son los que quedan\n", elim);
   mostrarLista(&lista);
}

void arbol(void)
{
   t_arbol  a1,
            a2;

   crearbolesYCargar(&a1, &a2);

   printf("El 1er arbol %ses AVL\n", esAVL_2(&a1) ? "" : "NO ");

   printf("El 2do arbol %ses AVL\n", esAVL_2(&a2) ? "" : "NO ");
            ///  reemplazar el uso de es AVL_2 por su propia versi�n
}
