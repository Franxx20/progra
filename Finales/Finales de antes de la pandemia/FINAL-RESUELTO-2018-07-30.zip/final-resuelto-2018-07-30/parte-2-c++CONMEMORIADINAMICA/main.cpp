#include "Persona.h"
#include <iostream>
using namespace std;



int main()
{
    cout << "Probando personas:" << endl<<endl;
    probarPersonas("Martinez", "Perez","Martina",  "Pedro",'F',        'M',22,         33);

    return 0;
}

void probarPersonas(const char *ape1, const char *ape2,
                    const char *nom1, const char *nom2,
                    char sex1, char sex2, int edad1, int edad2)
{
   Persona  p1(ape1, nom1, sex1, edad1),
            p2(ape2, nom2, sex2, edad2),
            p3(p1),
            p4;

    cout << "Valores iniciales :" << endl
        << "p1"  <<endl<< p1<<endl<<endl 
       << "p2"  << endl<<p2<<endl<<endl 
         << "p3"  << endl<<p3<<endl<<endl 
        << "p4"  <<endl<< p4<<endl<<endl ;
   p4 = p3;
   p4++;  // modifica la edad

   cout << "Valores finales:" << endl
        << "p1" << endl << p1 << endl << endl
        << "p2" << endl << p2 << endl << endl
        << "p3" << endl << p3 << endl << endl
        << "p4" << endl << p4 << endl << endl;
   if(p1 == p4)
      cout << p1 << "es identico a" << endl << p4 << endl << endl;
}
