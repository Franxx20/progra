#include "Persona.h"
#include <string.h>
Persona::Persona()
{
  
    this->tamape=0;
    this->tamnom=0;
    this->edad=0;
    this->sexo=' ';
    this->ape=new char [ this->tamape+1];
    this->nomm=new char [ this->tamnom+1];
    if(this->ape==NULL)
    {
        throw bad_alloc();
    }
     if(this->nomm==NULL)
    {
        throw bad_alloc();
    }
    this->ape[0]='\0';
    this->nomm[0]='\0';
    
}

Persona::~Persona()
{
    delete []this->ape;
    delete []this->nomm;
}
Persona::Persona(const char* ape1, const char* nom1, char sex1, int edad1)
{
    this->tamape=strlen(ape1);
    this->tamnom=strlen(nom1);
    this->edad=edad1;
    this->sexo=sex1;
    this->ape=new char [ this->tamape+1];
    this->nomm= new char [this->tamnom+1];
    if(this->ape==NULL)
    {
        throw bad_alloc();
    }
     if(this->nomm==NULL)
    {
        throw bad_alloc();
    }
    strcpy(this->ape,ape1);
    strcpy(this->nomm,nom1);
    
}
Persona::Persona(Persona& obj)
{
  
     this->tamape=strlen(obj.ape);
    this->tamnom=strlen(obj.nomm);
    this->edad=obj.edad;
    this->sexo=obj.sexo;
    this->ape=new char [ this->tamape+1];
    if(this->ape==NULL)
    {
        throw bad_alloc();
    }
    this->nomm= new char [this->tamnom+1];
     if(this->nomm==NULL)
    {
        throw bad_alloc();
    }
    strcpy(this->ape,obj.ape);
    strcpy(this->nomm,obj.nomm);

}
ostream & operator << (ostream & salida ,const Persona & obj)
{
    salida<<obj.ape<<obj.nomm<<obj.sexo<<obj.edad<<endl;
    return salida;
}
Persona& Persona::operator=(const Persona& obj)
{
    delete []this->ape;
    delete []this->nomm;
     this->tamape=strlen(obj.ape);
    this->tamnom=strlen(obj.nomm);
    this->edad=obj.edad;
    this->sexo=obj.sexo;
    this->ape=new char [ this->tamape+1];
    this->nomm=new char [this->tamnom+1]; 
    if(this->ape==NULL)
    {
        throw bad_alloc();
    }
     if(this->nomm==NULL)
    {
        throw bad_alloc();
    }
    strcpy(this->ape,obj.ape);
    strcpy(this->nomm,obj.nomm);
    return *this;
}

bool Persona::operator==(const Persona& obj)
{
    if( (strcmp(this->ape,obj.ape))==0 && (strcmp(this->nomm,obj.nomm))==0&& this->edad==obj.edad&&this->sexo==obj.sexo )
        return 1;
    return 0;
}
Persona  Persona::operator++(int)
{
        Persona aux;
        aux.tamape=strlen(this->ape);
        aux.tamnom=strlen(this->nomm);
          aux.edad=this->edad+1;
            aux.sexo=this->sexo;
           aux.ape=new char [ aux.tamape+1];
           aux.nomm=new char [aux.tamnom+1];
           
        if(aux.ape==NULL)
    {
        throw bad_alloc();
    }
            
    if(this->nomm==NULL)
    {
        throw bad_alloc();
    }
    strcpy(aux.ape,this->ape);
    strcpy(aux.nomm,this->nomm);
    return aux;
}