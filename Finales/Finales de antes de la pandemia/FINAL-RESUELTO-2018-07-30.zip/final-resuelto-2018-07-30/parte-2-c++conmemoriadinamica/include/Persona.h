#ifndef PERSONA_H
#define PERSONA_H
#include <iostream>
#include <stdexcept>
using namespace std;
void probarPersonas(const char *ape1, const char *ape2,
                    const char *nom1, const char *nom2,
                    char sex1, char sex2, int edad1, int edad2);
class Persona
{
    public:
        Persona();
        ~Persona();
        Persona( const char *ape1, const char *nom1,char sex1, int edad1);
        Persona(Persona & obj);
        friend ostream & operator << (ostream & salida ,const Persona & obj);
        Persona & operator = ( const Persona & obj);
        Persona  operator ++(int);
        bool operator == (const Persona & obj);

    private:
        char *ape,*nomm;
        char sexo;
        int edad;
        int tamape;
        int tamnom;
};

#endif // PERSONA_H
