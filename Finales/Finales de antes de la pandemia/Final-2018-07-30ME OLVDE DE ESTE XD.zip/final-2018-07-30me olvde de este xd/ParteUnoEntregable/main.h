#ifndef MAIN_H__
#define MAIN_H__

#define FI           2
#define CO           4
#define CO_FI        3
#define VERDADERO 1
#define FALSO 0

void prodMat(void);
void mat1_b(void);
void lista(void);
void arbol(void);


#endif
