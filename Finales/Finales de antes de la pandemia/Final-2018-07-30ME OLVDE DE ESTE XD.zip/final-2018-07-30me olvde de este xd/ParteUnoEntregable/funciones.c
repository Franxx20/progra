#include <stdio.h>
#include <stdlib.h>

#include "main.h"
#include "funciones.h"

#include <math.h>




///** funciones a desarrollar
/*void multiplicar(int m[][CO_FI], int n[][CO], int r[][CO])
{

}*/


void multiplicar(int m[][CO_FI], int n[][CO], int r[][CO])
{
  int i,j,k;
  for(i=0;i<CO_FI;i++)
  {
    for(j=0;j<CO_FI;j++)
    {
       r[i][j]=0;
       for(k=0;k<CO_FI;k++)
       {
           r[i][j]+= m[i][k] *n[k][j];
       }
    }

  }
}
int esIdentidad(int m[][CO])
{

    int i, j;

    for(i=0; i<CO; i++)
    {
        for(j=0; j<CO; j++)
        {
            if(i==j)
            {
                if(m[i][j]!=1)
                    return 0;
            }
            else
            {
                if(m[i][j]!=0)
                    return 0;
            }
        }
    }
    return 1;



/*
    int i,j,cont=0;
    for(i=0; i<CO; i++)
    {
        for(j=0; j<CO; j++)
        {
            if(m[i][i]==1)
            {
                cont++;
            }
            else if(m[i][j]==0)
            {
                cont++;
            }
            printf("%d",m[i][j]);
        }

        printf("\n");
    }
    if(cont==CO*CO)
        printf("\nes identidad\n");
    else
        printf("\nno es identidad\n");

  return 1;
  */
}

int  eliminarUnicos(t_lista *p)
{
    t_nodo **act, **com, **nae, **aux;
    int dup, i, sub=0, tot=0, ban=0;
    char vec[10][11];

    if(!*p)
        return 0;

    act=p;

    /*if(act->ant)
        act=act->ant;*/

    com=&(*act)->sig;
    while(com)
    {
        dup=0;
        while(*com && !dup)
        {
            if(strcmp((*act)->info.codigo, (*com)->info.codigo)==0)
                dup++;

            com=&(*com)->sig;
        }

        aux=&(*act)->sig;
        if(!dup)
        {
            for(i=0; i<=sub; i++)
            {
                if(sub && strcmp((*act)->info.codigo, vec[i])==0)
                    ban=1;
                    tot--;
            }
            if(ban==0)
            {
                nae=act;
                if(p==act)
                    p=aux;
                free(*nae);
            }
            ban=0;
        }
        else
        {
            strcpy(vec[sub], (*act)->info.codigo);
            sub++;
        }

        act=aux;
        com=&(*act)->sig;
        tot+=dup;
    }

    *p=*act;
    printf("Se eliminaron %d nodos. \n", tot);
    return 1;
}

/*int esAVL(const t_arbol *p)
{

}*/

int es_AVL(const t_arbol *pa)
{
    if(!*pa)
        return VERDADERO;
    int hi=alturaArbol(pa);
    int hd=alturaArbol(pa);

    if(abs(hi-hd)>1)
        return FALSO;
    return (es_AVL(&(*pa)->izq) && es_AVL(&(*pa)->der));
}
int alturaArbol(const t_arbol *pa)
{
    if(!*pa)
        return 0;
    int hi=alturaArbol(&(*pa)->izq);
    int hd=alturaArbol(&(*pa)->der);

    return hi > hd ?hi+1:hd+1;
}
