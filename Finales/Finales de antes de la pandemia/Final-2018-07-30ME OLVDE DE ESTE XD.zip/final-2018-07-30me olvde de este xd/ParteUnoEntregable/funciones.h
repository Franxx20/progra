#ifndef FUNCIONES_H_
#define FUNCIONES_H_

#include <string.h>

#include "main.h"

#define FI 2
#define CO 4
#define CO_FI 3


void multiplicar_2(int m[][CO_FI], int n[][CO], int r[][CO]);

void multiplicar(int m[][CO_FI], int n[][CO], int r[][CO]);

int esIdentidad_2(int m[][CO]);

int esIdentidad(int m[][CO]);

void mostrar(const char *msj, int *p, int filas, int columnas);

typedef struct
{
   char     codigo[11];
   float    importe;
} t_info;

typedef struct s_nodo
{
   t_info            info;
   struct s_nodo    *sig;
} t_nodo, *t_lista;

void crearListaYCargar(t_lista *p);
int  mostrarLista(const t_lista *p);

int  eliminarUnicos_2(t_lista *p);
int  eliminarUnicos(t_lista *p);


#define  SIN_MEM     1
#define  CLA_DUP     2
#define  TODO_BIEN   0

typedef struct
{
   char cad[4];
} t_infoAr;

typedef struct s_nodoAr
{
   t_infoAr info;
   struct s_nodoAr  *izq,
                    *der;
} t_nodoAr, *t_arbol;

void crearbolesYCargar(t_arbol *a1, t_arbol *a2);

int esAVL_2(const t_arbol *p);
int es_AVL (const t_arbol *);
int alturaArbol(const t_arbol *);

#endif
