/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* AC� NO DEBE HACER NINGUNA MODIFICACI�N                         *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>

#include "funciones.h"

#include <stdlib.h>
#include <string.h>


void punto_1(FILE *fpPantalla, unsigned nroLote);


void punto_2(FILE *fpPantalla, unsigned queArchivos);


#endif

