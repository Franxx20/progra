#include "RectaException.h"



