#include <math.h>

#include "RectaException.h"
#include "Recta.h"



