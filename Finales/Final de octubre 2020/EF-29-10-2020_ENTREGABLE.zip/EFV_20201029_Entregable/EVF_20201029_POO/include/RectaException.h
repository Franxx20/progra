#ifndef RECTAEXCEPTION_H
#define RECTAEXCEPTION_H

#include <string>

using namespace std;


class RectaException
{




#endif // RECTAEXCEPTION_H
