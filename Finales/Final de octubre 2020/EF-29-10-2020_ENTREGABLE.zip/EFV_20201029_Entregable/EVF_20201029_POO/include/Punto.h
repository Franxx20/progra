#ifndef PUNTO_H
#define PUNTO_H

#include <iostream>

using namespace std;


class Punto
{



#endif // PUNTO_H
