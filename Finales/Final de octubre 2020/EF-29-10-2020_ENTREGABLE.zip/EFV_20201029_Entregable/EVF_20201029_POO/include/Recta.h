#ifndef RECTA_H
#define RECTA_H

#include <iostream>

#include "Punto.h"

using namespace std;


class Recta
{



#endif // RECTA_H
