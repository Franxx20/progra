#ifndef PUNTO_H
#define PUNTO_H

#include <iostream>

using namespace std;


#endif // PUNTO_H
